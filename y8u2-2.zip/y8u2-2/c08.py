# DO NOT CHANGE THIS NEXT LINE
powers = [ 1, 10, 8, 100, 1000 ]

# => Take the number that is not a power-of-10 
# out of the list called 'powers'
_.remove(_)

print(powers)
