# DO NOT CHANGE THESE FIRST FOUR LINES
like = [ 'Sweets', 'Crisps', 'Fruit', 'Spinach' ]

print(like)
print("Which of these don't you like?")
yuck = input()

# => Take the thing called 'yuck' out of 
# the list called 'like'
like.remove(_)

print(like)
