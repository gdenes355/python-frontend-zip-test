# DO NOT CHANGE THESE FIRST 3 LINES
numbers = [ 2, 98, 8, 23, "Bananas", 37, 9, 1 ]
big = []
small = []

# => (1) Remove 'Bananas' from the list of numbers


x = 0
while x < 7:
  
  n = numbers[x]

  if n > 20:
    # => (2) put n onto the end of the list called 'big'
    
  else:
    # => (3) put n onto the end of the list called 'small'
    
  x = x + 1

print("The big numbers are", big, "and the small ones are", small)
