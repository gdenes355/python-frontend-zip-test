# DO NOT CHANGE THIS NEXT LINE
letters = [ "A", "B", "C" ]

# => Replace the blanks to put the next two letters of the alphabet 
# onto the end of the list 'letters'
_.append("D")
_.append("E")

print(letters)
