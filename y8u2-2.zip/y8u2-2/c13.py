# DO NOT CHANGE THIS NEXT LINE
letters = [ 'X', 'Y', 'Z', '*' ]

# => Use pop to remove the last thing from the list
letters.pop(_)

print("The letters are", letters)
