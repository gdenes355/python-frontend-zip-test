# DO NOT CHANGE THESE FIRST 3 LINES
colours = [ "Red", "Green", "Blue" ]

print("Enter a colour")
c = input()

# => Write a line of code to put the colour that was entered onto the end of the list of colours


print(colours)
