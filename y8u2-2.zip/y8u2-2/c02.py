# DO NOT CHANGE THIS NEXT LINE
y = [ 2, 4, 6, 8 ]

# => Put the next two even numbers onto the end of the list y
y.append(_)
y.append(_)

print(y)
