# DO NOT CHANGE THIS NEXT LINE
register = [ 'George', 'Sophie', 'Alex' ]

# => George has to leave the class, use remove 
# to take him out of the list


# => Polly comes back from a music lesson, add 
# her to the end of the list using append


# => The second person in the class list has 
# forgotten their book, and leave to get 
# it from their locker. Use pop to take 
# the second person out of the register



print("The final class register is", register)
