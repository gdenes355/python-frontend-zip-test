# DO NOT CHANGE THIS NEXT LINE
zoo = [ 'Camel', 'Penguin', 'Tiger', 'Zebra', 9 ]

# => Use pop to remove the number from the list called zoo


print("The zoo is", zoo)
