# DO NOT CHANGE THIS NEXT LINE
queue = [ "Sam", "Errol", "Joe" ]

# => Use append to put "Fred" onto the end 
# of the queue


# => Now use pop to take the first person out of the queue


print("The queue is now", queue)
