# DO NOT CHANGE THIS NEXT LINE
fairground_game = [ "Duck" , "Tree", "Duck", "Gap", "Duck" ]

x = 0
while x < 3:
  # => Use remove to remove a Duck from the fairground_game
  
  x = x + 1

print("The game is now", fairground_game)
