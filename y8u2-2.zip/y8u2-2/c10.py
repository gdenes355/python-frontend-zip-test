# DO NOT CHANGE THESE FIRST FOUR LINES
subjects = [ 'Maths', 'Art', 'Drama', 'Biology' ]

print(subjects)
print("Which of these subjects will you drop?")
drop = input()

# => Take the thing called 'drop' out of the list 'subjects'
_.remove(_)

print(subjects)
