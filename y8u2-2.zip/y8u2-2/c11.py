# DO NOT CHANGE THIS NEXT LINE
numbers = [ 1, 4, "fish", 9, 16]

# => Take the fish out of the list using remove


print("The numbers are", numbers)
