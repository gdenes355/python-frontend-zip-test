# DO NOT CHANGE THIS NEXT LINE
animals = [ "Ant", "Beetle", "Spider", "Table" ]

# => Take the non-animal out of the list
animals.remove(_)

print(animals)

