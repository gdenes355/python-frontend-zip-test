In this lesson you will practice
 - adding something to the end of a list using `append()`
 - removing something from a list using `remove()`
 - removing something from a list using its position, using `pop()`

