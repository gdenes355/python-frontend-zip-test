# DO NOT CHANGE THIS NEXT LINE
zoo = [ 7, 'Camel', 'Penguin', 'Tiger' ]

# => Use pop to remove the number from the list called zoo


print("The zoo is", zoo)

