# DO NOT CHANGE THIS NEXT LINE
letters = [ 'X', '!', 'Y', 'Z' ]

# => Use pop to remove the ! symbol from the list
letters.pop(__

print("The letters are", letters)
