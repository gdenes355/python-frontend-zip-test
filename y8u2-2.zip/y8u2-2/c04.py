# DO NOT CHANGE THESE FIRST 3 LINES
fastfood = [ "Chips", "Nandos", "Pizza" ]

print("Enter some fast food")
f = input()

# => Complete this line to add the food the user entered to the end of the list
fastfood.append(_)

print(fastfood)
