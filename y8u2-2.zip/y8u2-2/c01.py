# DO NOT CHANGE THIS NEXT LINE
x = [ 1, 2, 3, 4 ]

# => Put the next number in the sequence onto the end of the list x
x.append(_)

print(x)
