# DO NOT CHANGE THIS NEXT LINE
odds = [ 1, 3, 5, 6, 7, 9 ]

# => 6 isn't odd, complete the blank to remove it
odds.remove(_)

print(odds)

