# DO NOT CHANGE THESE FIRST 7 LINES
numbers = [ 7 ]

print("Enter a number")
numbers.append(int(input()))

print("Enter a number")
numbers.append(int(input()))

print("Enter a number")
numbers.append(int(input()))

# => Count the number of 7s in the list of numbers
num = _

print("There are", num, "7s.")
