# DO NOT CHANGE THIS NEXT LINE
animals = [ "Ant", "Beetle", "Spider", "Table" ]

# => Find the position of Table and then use pop to remove it
t = animals.index(_)
animals.pop(t)

# NOTE: we could have just used .remove of course as a one-liner!

print(animals)

