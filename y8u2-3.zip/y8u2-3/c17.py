# DO NOT CHANGE THIS NEXT LINE
queue = [ 'Errol', 'Fred', 'Joe' ]

# => Use sort to put the queue in order


print("The ordered queue is",queue)

# => Now use index to find where Joe is in the queue

j = _

print("Here is Joe:", queue[j])

# => Now use pop to take Joe out of the queue

queue.pop(_)

# => Now use count to prove that Joe is not in the queue any more

c = _.count(_)

print("Number of Joes in the queue:", c)
print(queue)
