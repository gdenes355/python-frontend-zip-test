# DO NOT CHANGE THESE FIRST 4 LINES
like = [ 'Sweets', 'Crisps', 'Fruit', 'Spinach' ]

print(like)
print("Which of these don't you like?")
yuck = input()

# => Find the position of the variable 'yuck' in the list called 'like'
x = like.index(_)

# => Use pop to remove the item at that position
like.pop(_)

# (extension: once you have the marks, try replacing line 9 & 12 with a single line which uses .remove to do the same job)

print(like)
