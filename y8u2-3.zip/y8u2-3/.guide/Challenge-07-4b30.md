Adi wants to allow the user to enter four kings or queens of England and then finally print out an alphabetically sorted list of monarchs. Note that the names entered are case-sensitive e.g. Edward is before edward.

Follow the instructions in the code. Make sure to test it using the **Debug** button before testing it with **Submit**.








