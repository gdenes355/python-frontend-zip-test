You have now completed the main content for this module.

Enjoy the extension skills on the following pages.

You will learn about the `.index()`, `.count()` and `.insert()` methods on the remaining tasks.

