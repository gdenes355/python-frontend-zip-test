Now investigate the following using W3 Schools Python Tutorial:

a) the insert() method

https://www.w3schools.com/python/ref_list_insert.asp


b) how the .pop() method also returns the item it is removing so you can store it in a variable or print it

https://www.w3schools.com/python/ref_list_pop.asp
(look at the second example on this page in particular)

c) other useful python list methods

https://www.w3schools.com/python/python_ref_list.asp

Then try your hand at the codingbat.com Python list challenges! Create an account to track your progress: how many can you solve?

https://codingbat.com/python/List-1
https://codingbat.com/python/List-2
