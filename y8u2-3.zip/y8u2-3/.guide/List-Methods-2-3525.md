In this lesson you will practice
 - sorting a list using `.sort()`
 - practising all our list skills together 
 
Extension:
 - finding the index of an item in a list using `.index()`
 - counting how many of an item is in a list using `.count()`
 - inserting an item at a specific place in the list using `.insert()`

