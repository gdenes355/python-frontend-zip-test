Julie wants to allow the user to enter three more pets and print out an updated alphabetically sorted list of pets after each new addition.

Follow the instructions in the code. Make sure to test it using the **Debug** button before testing it with **Submit**.




