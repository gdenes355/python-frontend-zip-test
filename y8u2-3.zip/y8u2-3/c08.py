# DO NOT CHANGE THIS NEXT LINE
powers = [ 1, 10, 8, 100, 1000 ]

# => find and print the index position of the number that 
# is NOT a power-of-10 out of the list called 'powers'
position = _.index(8)

print(position)
