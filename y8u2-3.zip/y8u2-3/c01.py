# DO NOT CHANGE THIS NEXT LINE
x = [ 2, 3, 1, 4 ]

# => Complete this line to sort the list
x.sort

print(x)
