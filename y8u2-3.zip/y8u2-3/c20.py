# DO NOT CHANGE THIS NEXT LINE OR THE PROMPTS
register = [ 'George', 'Sophie', 'Alex' ]

# => Someone has to leave the class, use input
# to ask the user who it is and then remove
# them from the list
_ = input("name:")



# => Someone comes back from a music lesson,
# use input to ask who it is and add them
# to the end of the list

_ = input("name:")



# => Sort the list of names into alphabetical order


# => The second person alphabetically in the
# register has to leave. Remove them.



print("The final class register is", register)
