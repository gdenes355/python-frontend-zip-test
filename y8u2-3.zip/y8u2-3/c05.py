# DO NOT CHANGE THIS NEXT LINE
colours = [ "Red", "Green", "Blue" ]

# Write a line of code to sort the list of colours


print(colours)
