# DO NOT CHANGE THESE NEXT 3 LINES
zoo = [ 'Camel', 'Penguin', 'Tiger', 'Zebra' ]

print("Enter an animal")
animal = input()

# Use count to find how many of that animal there is in the zoo
num = _

print("There are", num, animal, "in the zoo.")
