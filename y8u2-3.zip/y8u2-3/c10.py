# DO NOT CHANGE THESE FIRST 4 LINES
subjects = [ 'Maths', 'Art', 'Drama', 'Biology' ]

print(subjects)
print("Which of these subjects will you drop?")
drop = input()

# => Find the position of 'drop' in the list of subjects
p = _.index(_)

# => Use pop to remove the item at position 'p'
# from the list of subjects
_.pop(_)

print(subjects)
