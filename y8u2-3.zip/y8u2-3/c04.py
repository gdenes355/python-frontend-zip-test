# DO NOT CHANGE THESE FIRST 3 LINES
fastfood = [ "Chips", "Nandos", "Pizza" ]

print("Enter some fast food")
f = input()

# => add the food to the end of the list
# (correct the error)
fastfood.append f

# => Sort the list of fast food
# (correct the error)
fastfood sort()

print(fastfood)
