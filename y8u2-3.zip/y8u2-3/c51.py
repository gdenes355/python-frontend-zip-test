# DO NOT CHANGE THIS NEXT LINE
pets = ["fish", "cat", "pony", "dog"]

count = 0

# => COMPLETE THE GAPS AND FIX THE ERROR BELOW

while count < 3:
  pet = input("Enter your next pet:")
  pets.append(___)
  pets.sort
  print("Your new alphabetically sorted list of pets is:")
  print(pets)
  count = count + ___
  

