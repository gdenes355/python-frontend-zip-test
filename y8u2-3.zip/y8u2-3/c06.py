# DO NOT CHANGE THIS NEXT LINE
odds = [ 1, 3, 5, 6, 7, 9 ]

# => find the index of the number 6 in the list
position = odds.index(_)

# use pop to remove the item at that position
odds.pop(position)

# NOTE: we could have just used .remove of course as a one-liner!

print(odds)

