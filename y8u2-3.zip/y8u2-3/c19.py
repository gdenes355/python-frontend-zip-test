# DO NOT CHANGE THESE FIRST 3 LINES
numbers = [ 2, 98, 8, 23, "Bananas", 37, 9, 1 ]
big = []
small = []

# => (1) Remove 'Bananas' from the list of numbers
numbers remove Bananas

# => (2) Sort the list of numbers


# => (3) Read the first four items in the list
first = numbers[_]
second = numbers[_]
third = numbers[_]
fourth = numbers[_]

# => (4) Use append to put the four numbers onto the end of the list called small.
small append first

# => (5) Get the 5th, 6th and 7th numbers 
fifth = 


# => (6) use append to put these three onto the list called 'big'



# => (7) Sort the list called big AND the list called small

big sort


print("The big numbers are", big)
print("The small numbers are", small)
