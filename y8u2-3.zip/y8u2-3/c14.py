# DO NOT CHANGE THIS NEXT LINE
letters = [ 'X', '!', 'Y', '!', 'Z' ]

# => Count the number of ! in letters
num = _.count('!')

print("There are", num, "! signs.")
