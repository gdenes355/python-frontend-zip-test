# DO NOT CHANGE THIS NEXT LINE
fairground_game = [ "Duck" , "Tree", "Duck", "Gap", "Duck" ]

# => Count the number of ducks in the game
ducks = _.count(_)

print("There are", ducks, "ducks.")

# We are going to use a while loop to repeat some code
count = 1
while count <= ducks:
  # => Use remove to get rid of a duck
  fairground_game.
  
  print("Bang. Hit one.")
  count = count + 1

print(fairground_game)
