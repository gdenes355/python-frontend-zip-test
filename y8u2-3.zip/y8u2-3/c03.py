# DO NOT CHANGE THIS NEXT LINE
letters = [ "E", "A", "B" ]

# => Put C and D onto the end of the list 'letters'
_.append("C")
_.append("D")

# => Then sort the list of letters
z.sort(

print(letters)
