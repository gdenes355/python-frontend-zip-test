# DO NOT CHANGE THIS NEXT LINE
monarchs = []

# => COMPLETE THE GAPS BELOW

count = ___

while count < 4:
  monarch = input("Enter another king or queen of England:")
  monarchs.append(___)
  count = count + 1

# => ADD A LINE HERE TO SORT THE LIST
  
print("Here are your kings or queens arranged alphabetically:")
print(___)