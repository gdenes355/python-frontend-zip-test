# DO NOT CHANGE THIS NEXT LINE
letters = [ '*', 'X', 'Y', 'Z', '*' ]

# => count the number of asterisks in the list 
num = letters.count(_)

print("There are", num, "* signs.")
