# DO NOT CHANGE THIS NEXT LINE
numbers = [ 1, 4, "fish", 9, 16]

# => Take the fish out of the list using the index() and pop() methods
position = numbers.index
numbers.pop

print("The numbers are", numbers)
