# DO NOT CHANGE THIS NEXT LINE
letters = [ '%', 'X', '%', 'Y', 'Z', '%' ]

# Count the number of % in the list
num = letters.count

print("There are", num, "% signs.")
