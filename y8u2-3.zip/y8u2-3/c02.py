# DO NOT CHANGE THIS NEXT LINE
y = [ 6, 2, 8, 4 ]

# => Sort the list
y.sort

# => Complete the blank to print out the first item
print(y[_])

