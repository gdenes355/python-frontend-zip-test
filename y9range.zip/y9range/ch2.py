for num in range(5, 0, -1):
    print(num)
print("blast off!")