for num in range(2, 14, 2):
    sq = num ** 2
    print(sq)

for num in range(1, 13, 2):
    sq = num ** 2
    print(sq)
