Put the blocks in the right order. 

Press `Debug` to check the output of your program

Press `Submit` to check if you got everything right.