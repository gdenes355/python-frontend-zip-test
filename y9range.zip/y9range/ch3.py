bottles = int(input("number of bottles? "))
for _ in range(2):
    print(bottles, "green bottles")
    print("standing on the wall")
print("and if one green bottle should accidentally fall")
print("there'd be", bottles - 1, "green bottles standing on the wall")