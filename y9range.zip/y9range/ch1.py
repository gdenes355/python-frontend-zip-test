for i in range(5):
    print("hello")
print("goodbye")