a = 3
b = 9
print(a + b)

