# The user will keep entering numbers, finishing with -1. Add up any numbers smaller than 10 (but not the finishing '-1'), and then print the result

total = 0

print("Enter a number")
n = int(input())


print("The total was",total)
