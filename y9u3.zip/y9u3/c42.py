# Show the first n square numbers 

num = int(input())

x = 1
while x <= num
x = x + 1
print(x)
