print("Magnificent"
