# If the user enters a number smaller than 10, ask them for a word and print it the number of times that they first entered. If the user's first number is bigger than 10, print the square of that number.

print("Enter a number")
n = int(input())

print("Enter a word")
w = input()

