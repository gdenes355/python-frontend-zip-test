x = input
print ("[x]")

