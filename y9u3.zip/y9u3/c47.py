repeat = True

while repeat == True
  print("input your height in cm")
  height = int(input())
  if height >=0 and height <= 1000:
    repeat = False
      
print("So you are", height, "cm tall")
