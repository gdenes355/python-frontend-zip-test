# Write some code to get input from the user, which will be a number.
# If the number is bigger than 42, show 'Zaphod'. If the number is smaller than 13, show 'Ford'. If the number is 17, show 'Arthur'. For all other numbers, show 'ZZ9 Plural Z Alpha'

