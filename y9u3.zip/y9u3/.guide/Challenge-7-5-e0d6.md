Keep asking for numbers as input, but stop when `-1` is entered and print how many numbers were entered (excluding the final '-1'). The variable `count` is used to keep a count of how many times the loop is run, but note, how this is still not a count-controlled repetition, as the `while` loop is conditional on the `repeat` flag variable.





