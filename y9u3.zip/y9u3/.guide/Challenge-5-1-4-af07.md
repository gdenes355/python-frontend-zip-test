Write some code to get input from the user, and if they enter `Agent Smith` then you should print `Mr. Anderson`. Print `Finished` at the end of your program.





