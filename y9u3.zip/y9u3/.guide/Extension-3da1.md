You have finished the core course. Now go on to try these extension problems:

 - project euler challenges 1-10
 - coding bat warmup-1, warmup-2, logic-1, logic-2
 - PCTC Round 1 Practice
