The user will enter 6 numbers. For each number you must print whether it is smaller than 5, bigger than 5 or exactly 5. This will be an `if/elif/else` statement inside a `while` loop





