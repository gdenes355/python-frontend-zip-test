You can also print more complicated series. For examples, the code below will print the first `num` even numbers.
```python
num = int(input())

x = 1
while x <= num:
  print(x * 2)
  x = x + 1
```
Notice how the increment is still at the end of the loop, unchanged (`x = x + 1`).

---
Now, complete the code on the left so that it prints the first `num` square numbers. e.g. if `4` is entered then the output should be:
```
1
4
9
16
```

Hint: you can find the square of a number by multiplying with itself. Or, you could use the [`**` operator](https://www.w3schools.com/python/trypython.asp?filename=demo_oper_exp) 





