You can print a piece of text in Python using the `print` keyword. The string (the piece of text) you want to print needs to be between speech marks (`""`). For example, the following Python code prints `Hello World`:

```python
print("Hello world")
```

Now fix any syntax errors so that `Success` is printed. Make sure you always use the `Debug` button below to run your program in the terminal first before hitting the `Check it` button.






