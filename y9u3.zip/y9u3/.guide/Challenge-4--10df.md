The code should get the user to enter 5 numbers greater than 0 (using a count-controlled loop). Print the largest one at the end. 

You can do this by keeping a variable that is currently the largest on you've seen. Each time around the loop, compare the new number to the largest and if it is bigger, then update your `largest` variable. In pseudocode:
```markdown
max = 0 (something smaller than any number the user inputs)
x = 1
repeat 5 times:
    input y
    if x < y then
       x = y as we found a new maximum
```





