Write some code to get input from the user, which will be a number. If they enter `271` then you should print `e for echo`. If they enter any other number you should print `y for yankee`.





