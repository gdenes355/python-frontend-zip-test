Can you correct all the syntax errors (and one logical error) in this code so that it prints the first `n` terms of the 7-times-table?

---
Hint: beyond the syntax error, you will also need to make sure that the program doesn't print out `0` for all products. Remember, you should never have to change the increment line which is the last indented line at the end of the loop (`x = x + 1`)





