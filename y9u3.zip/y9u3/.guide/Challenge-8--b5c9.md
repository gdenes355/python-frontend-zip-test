The user will enter either numbers, or the word `Stop`. You must add up any numbers smaller than 10, and count how many numbers are larger than 20. When `Stop` is entered, print the results.

|||info
The biggest challenge here is that your input might be a string, or an integer. Make sure you check whether it is `Stop` first, and only otherwise convert it into an integer with `x = int(x)`.
|||





