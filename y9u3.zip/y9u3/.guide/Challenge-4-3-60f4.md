The program will be given some user input by the test process. You need to print the value given inside curly braces `{}` with spacing. e.g. if `Sun` is input, then `{ Sun }` should be printed.





