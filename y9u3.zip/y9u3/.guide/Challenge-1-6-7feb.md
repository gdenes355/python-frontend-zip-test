Fix any syntax errors so that `Perfect` is printed.





