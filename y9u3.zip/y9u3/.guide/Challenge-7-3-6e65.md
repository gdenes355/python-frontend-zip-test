This code should keep asking for a number, rejecting anything smaller than 10. Print the first number that is at least 10, and do not ask for any more input.





