Fix any syntax errors so that `Woohoo` is printed.

*remember that you can always check your code from the previous challenge using the arrow buttons in the top bar*
<img src=".guides/img/arrows.png" style="width:50px">





