Fix any syntax errors so that `Magnificent` is printed.





