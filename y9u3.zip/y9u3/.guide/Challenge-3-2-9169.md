The program will be given some user input by the test process. Fix the syntax errors so that whatever is input gets printed.





