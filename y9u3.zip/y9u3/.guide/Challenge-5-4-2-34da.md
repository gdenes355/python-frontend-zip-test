Our street has houses numbered from 1 -- 10. *Odd* numbered houses are on the `North` side of the street and *even* numbered houses are on the `South` side of the street. Amend (fix and complete) the code so that the correct side (`North` or `South`) is printed if the house number is entered.





