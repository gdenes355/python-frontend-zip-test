In this example, the input will be a number. You can turn any variable into an integer using `int()`. For example:

```python
keypad = input()
keypad = int(keypad)
```

The first line takes the string input, and the second line turns the keypad variable into an integer. These two instructions are often compressed into a single line:

```python
keypad = int(input())
```

---

Can you fix all the syntax errors in the code so that if the value entered on the keypad is incorrect, `Go Away` is printed?





