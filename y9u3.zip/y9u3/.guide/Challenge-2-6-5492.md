Put the lines in order so that `42` is printed. Do not change the content of the lines.





