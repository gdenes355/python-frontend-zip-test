Python allows you to construct expressions using a variety of comparison operators:
 - `==` is equal to (you have been using this one so far)
 - `<` is less than
 - `<=` is less than or equal to
 - `>` is greater than
 - `>=` is greater than or equal to
 - `!=` is not equal to
 
---

Our street has houses numbered 1 -- 10. Houses numbered 1--5 are on the East side of the street and the others (6--10) are on the West side of the street. Complete the code so that the correct side (`East` or `West`) is printed if the house number is entered. Otherwise, for numbers outside the 1--10 range, it should print out `Error`.






