So far, we have used `while` loops for count-controlled repetition. However, we can also use them for *condition-controlled* repetition, when the programmer doesn't know in advance how many times their code will get executed.

A simple example of this is input validation. Imagine that we have a website which asks the user to enter their age. If the user enters something outside the expected range (let's say all users should be 10--99 years old), the website should just ask again. More than that, it should keep asking, *while* the user keeps on giving invalid input.
In Python, this would look like this:
```python
repeat = True 
while repeat == True:
  print("input your age")
  age = int(input())
  if age >=10 and age <= 99:
      repeat = False
      
print("So you are", age, "years old")
```

The important things to note:
- `repeat` is the *flag* variable, which controls whether the repetition should continue
- `repeat` is initially `True`, as we want the loop to run at least once
- we have a selection *inside* the loop (indented), which, when some condition is satisfied, sets `repeat` to `False`, telling Python to stop the loop

---

Now fix the program on the left so it keeps on asking the user's height in cm, until they enter something sensible (100--250). Do not change the print statements.





