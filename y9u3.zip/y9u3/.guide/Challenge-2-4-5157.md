Variables can be numbers as well. In Python, a whole number is called an `int` (short for integer), a real number is called a `float`.

For example, this program prints out the area of a circle

```python
radius = 5
pi = 3.14
print(radius * radius * pi)
```

Notice how there is no speechmark when assigning number variables.

Fix the **first line** of the code on the left to print out `42`.




