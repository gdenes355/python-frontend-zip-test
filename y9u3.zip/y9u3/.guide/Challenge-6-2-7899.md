When a number is entered by the user, this code should count up to that number, starting at 1. Fix the indentations in the code provided. No need to change their order.

|||warning
If the increment (`x = x + 1`) is not inside the loop, then your program might be stuck in an infinite loop. If this happens, refresh the page to reload Codio.
|||





