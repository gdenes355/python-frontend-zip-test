Can you fix this program so that if the value provided is `Trinity` then `I know kung foo.` is printed? The program should always print `Finished` at the end.





