Now you are going to learn about the `while` statement in Python. The `while` statement is used to repeat a block of code. The code that is repeated is *indented*. The `while` loop will run if the condition is **True**.

We can use `while` statements to create *count-controlled repetitions* (i.e. repeat a part of the code a set number of times)
For example, the following code will print out the numbers `1` to `3`, then prints out `Finished`
```python
x = 1
while x <= 3:
    print(x)
    x = x + 1
print("Finished")
```
Notice a few things:
- `while` is lowercase, just like `if`, `else` and `elif`
- there is a colon at the end of the `while` line, just like in selections
- in a typical count-controlled repetition, you have a counter variable (here: `x`)
- the last line of a count-controlled repetition is the increment, where we increase the counter by 1. You should always make sure this line is in the correct place, and should always change the counter by 1.
- the first line that is _unindented_ after the while loop will be run after the loop is completed.

---

Now take a look at the program on the left. It all looks very similar to the example. Can you fix the syntax errors in this code so that the numbers 1 to 5, and then `Finished` is printed?





