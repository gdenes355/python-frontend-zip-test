You can write `if` statements in Python for selections. That is, if you want to only run part of your program when a condition is true. A few key points to remember:
* `if` is a keyword, and therefore it must be lowercase
* the `if` line must have a colon (`:`) at the end, after the condition
* to check if two things are equal, you must use double equal (`==`)
* you indicate what belongs to the body of the `if` statement using _indentation_ only. There is no `THEN` or `ENDIF`.
* anything after the loop that is _unindented_ will be always run after the loop, regardless of the condition.


For example, this piece of code will print out `Well done` only if you did your homework. It will always print `Finished` in the end.
```python
print("did you do your homework?")
answer = input()
if answer == "yes":
    print("Well done")
print("Finished")
```

---


You are now going to practice the syntax of the `if` statement. Can you fix this program so that if the value provided is `Neo` then `There is no spoon.` is printed? The program should always print `Finished` at the end.





