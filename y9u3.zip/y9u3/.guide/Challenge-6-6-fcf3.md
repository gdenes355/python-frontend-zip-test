This code is designed to print out the average test score from a class of 6 students by adding up their scores and finally dividing by 6.

You will need to 
- add the `while` line to start the count-controlled loop. Remember, you want to repeat 6 timex.
- fix the indentation to figure out what's inside and what's after the loop
- There are 2 coding changes needed too, where it says `# Need to change this line`.





