Print all the dominoes in a set of dominoes in the format: 

```
Double 1
1 : 2
1 : 3
...
1 : 6
Double 2
2 : 3
...
...
Double 6
```

You are given code with lines that are in the right order, but the indentation seems to have been removed (!) and there is some synyax missing. There is one `if/else` statement missing too. You'll work it out ...





