Python allows you to wait for the user to input a string with the `input()` function. 
This way, the program can customise its behaviour to the user. For example:
```python
print("What is your favourite food?")
food = input()
print("Really, I also like")
print(food)
```

---

Fix the syntax errors so that whatever is input gets printed.


While debugging, the terminal will wait for you to type something in, then hit the `Enter` key. When you hit `Check it`, the program will be given some user input by the test process. 





