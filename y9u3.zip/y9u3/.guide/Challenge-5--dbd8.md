This program should get the user to enter 6 numbers. Add up any ones **larger than 100**, and then print the result at the end. You will need a `while` loop with an `if` statement inside it.





