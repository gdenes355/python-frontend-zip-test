The value of any variable can be updated multiple times during the program. Re-arrange the lines to print out 
```html
The
Quick
Brown
Fox
```
Do not change the content of any line.




