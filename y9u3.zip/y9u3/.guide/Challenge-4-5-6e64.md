The program will ask the user for their first and second names, and then print a greeting using their full name. Can you get it to work?





