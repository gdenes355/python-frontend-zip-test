The program will be given some user input by the test process. Fix the syntax errors so that a message is printed - the text provided followed by `was input`.





