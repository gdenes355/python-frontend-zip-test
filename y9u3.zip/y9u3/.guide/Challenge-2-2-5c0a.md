Fix the syntax errors so that Harry Potter and the Chamber of Secrets is printed.




