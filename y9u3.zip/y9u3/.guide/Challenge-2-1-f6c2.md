In more complicated Python programs, you often want to use [variables](https://www.w3schools.com/python/python_variables.asp) which are named containers storing data values.

You can set the value of a variable using the equal sign. Notice how in this *assignment*, the name of the variable is always on the left, and the value is on the right side of the equal sign.
E.g.
```python
myFavouriteColour = "blue"
myFavouriteBird = "Kingfisher"
```
Each variable should have a unique name in your program. These names cannot contain any spaces. You can read more on variable names [here](https://www.w3schools.com/python/python_variables_names.asp).

Python's `print` statement can print the content of a variable. Notice how you do not need speech marks (`""`) when printing the variable.
```python
message = "Please wait while the matrix is loading"
print(message)
```

Amend the code on the left so it prints out the content of the `title` variable (`Harry Potter and the Philosopher's Stone`).




