---
The `print` function can print multiple things by separating the things to be printed with a comma (`,`). When displayed, Python will put a space between each thing printed. The example below prints `pi is approximately 3.14`.
```python
pi = 3.14
print("pi is approximately", pi)
```
  
---

Now look at the program on the left. The program will be given some user input by the test process, which is a name. Fix the syntax errors so that a greeting is printed - `Hello` followed by the name that is provided.





