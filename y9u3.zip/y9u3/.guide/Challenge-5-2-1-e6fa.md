You will now practice the `else` statement which is used along with `if`. The `else` part is run when the `if` condition is **False**. For example:
```python
print("Do you like Python so far?")
answer = input()
if answer == "yes":
    print("Great!")
else:
    print(":(")
print("Thanks for answering my question")
```

Can you fix the syntax errors in the code on the left so that the program runs as intended?

---
Hint: the same way an `if`-line ends with a colon (`:`), an `else`-line should also end with a colon (`:`).

---





