Fix any syntax errors so that `Cool Bananas` is printed.





