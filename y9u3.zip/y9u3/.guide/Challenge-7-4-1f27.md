Amend (finish) this code so it keeps on asking the user's name (printing out `What's your name?`), until the user enters `Godot`.

If the user enters `Godot`, the program should print `I've been waiting for you` in the end.

E.g.
```markdown
What's your name?
Alice
What's your name?
Bob
What's your name?
Godot
I've been waiting for you
```




