**Extend** this code so that if a is `Cool` and b is `Bananas` then `Australia` is printed. Also, if a is `Anakin` and b is `Skywalker` then `Darth Vader` is printed. If none of these combinations of input occur, then `Fade to black` is printed.
(To extend, you have to keep the current condition as well!)

---
Hint: you can use an `elif` with the right condition





