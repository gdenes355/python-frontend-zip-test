Fix any syntax errors so that `Excellent` is printed.





