The program should ask the user for their password, and then print it back on the screen with a message. Can you fix the syntax errors so that it works?





