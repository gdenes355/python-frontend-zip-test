Fix any syntax errors so that `Hot diggity dog` is printed.





