Can you fix this code, which keeps asking for a password, until `Sesame` is entered. Then it prints `Open` and finishes.





