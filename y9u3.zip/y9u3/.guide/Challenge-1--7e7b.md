From here on, last 11 challenges will use `if/elif/else` and `while`.

For this challenge, if the user enters a number smaller than 10, ask them for a word and print it the number of times that they first entered. If the user's first number is bigger than 10, print the square of that number.

e.g. if 3 is entered, then ask for a word. If the word is 'Cat' then the output should be:
```
Cat
Cat
Cat
```
e.g. if 12 is entered, then the output should be `144`





