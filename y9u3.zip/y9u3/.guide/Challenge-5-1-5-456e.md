Can you fix this program so that if the value provided is `Morpheus` then `I think he likes it.` is printed? The program should always print `Finished` at the end.





