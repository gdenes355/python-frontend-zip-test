The user will enter two numbers as co-ordinates on a graph, x and y. You should print out all whole-number co-ordinates in the rectangle given by the x-axis, y-axis and the co-ordinates given.

```
e.g. if x = 3 and y = 2 then you would print:

( 0 , 0 )
( 0 , 1 )
( 0 , 2 )
( 1 , 0 )
( 1 , 1 )
( 1 , 2 )
( 2 , 0 )
( 2 , 1 )
( 2 , 2 )
( 3 , 0 )
( 3 , 1 )
( 3 , 2 )
```

|||info
you will need 2 while-loops, one inside the other a bit like the last challenge

|||





