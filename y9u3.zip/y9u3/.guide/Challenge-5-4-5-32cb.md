Now, our street has houses numbered 1 -- 20. Houses numbered 1--5 **and 15--20** are on the East side of the street and the others (6--14) are on the West side of the street. Complete the code so that the correct side (`East` or `West`) is printed if the house number is entered. Otherwise, for numbers outside the 1--20 range, it should print out `Error`.

---
Hint: there are multiple approaches to solve this problem. You could think of a long boolean expression involving two `and`s and an `or`, or you could keep the conditions as simple as in the previous challenge, and use multiple `elif`s.





