So far, all of the comparisons have been single comparisons `==`. This is also called a simple boolean expression.
You can also use *compound* boolean expressions, where you connect *multiple comparisons* using `and` and `or`. An example of a such expression that is true on either day of the weekend is:

```python
day == "Saturday" or day == "Sunday"
```

Notice how the `or` connects two comparisons, each with its own is-equal sign (`==`). You could add brackets to help understand what Python sees:
```python
(day == "Saturday") or (day == "Sunday")
```
|||warning
in `day == "Saturday" or "Sunday"` the `or` is not between two comparisons, and will be **misunderstood** by Python.
|||

---

Complete the code so that if any vowel gets entered (`a`,`e`, `i`, `o`, `u` in lower case), then `Vowel` is printed. Else, `Consonant` is printed.





