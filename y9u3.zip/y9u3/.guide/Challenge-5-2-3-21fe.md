Write some code to get input from the user, which will be a number. If they enter `314` then you should print `Have some pie`. If they enter any other number you should print `Still cooking`





