An `if/else` statement allows you to branch your code into two paths using a single boolean condition. However, you can include more conditions and more branches using the `elif` keyword.
```python
if item == "carrot":
    print("40p")
elif item == "banana":
    print("80p")
else:
    print("I don't know how much it costs")
```


`elif` can be put between the `if` and the `else` (and you can have more than one). 
```python
if item == "carrot":
    print("40p")
elif item == "banana":
    print("80p")
elif item == "TV":
    print("£299.99")
else:
    print("I don't know how much it costs")
```

Python reads the selection from the top, picking the **first True condition**. The rest of the statement (even if multiple conditions could be true are ignored). The `else` is only run if all the conditions are False.
```python
if item == "carrot":
    print("40p")
elif item == "carrot":
    print("This line will be never reached by Python")
else:
    print("It's not a carrot")
```


---

Can you fix the syntax in this `if/elif/else` statement?





