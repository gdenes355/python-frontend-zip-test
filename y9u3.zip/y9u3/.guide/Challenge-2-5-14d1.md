Fix all syntax errors in the code to correctly print out the sum of 3 and 9 (`12`).
Do no change the print statement (last line of the code).





