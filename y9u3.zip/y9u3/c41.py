max = int(input())

print("Let's count to", max)

x = 1
while x <= max:
print(x)
x = x + 1

