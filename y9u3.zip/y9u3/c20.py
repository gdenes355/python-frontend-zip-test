f = input("What is your first name?")
s = input(What is your second name?)
print("Hello" f s)
