x = Input()
print(x)
