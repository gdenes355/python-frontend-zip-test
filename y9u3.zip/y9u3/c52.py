# The user will enter 5 numbers greater than 0. Print the largest one

largest = 0
x = 1

print("Enter a number")
n = int(input())


print("The largest was",largest)
