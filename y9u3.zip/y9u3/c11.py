x = input""
print(x)
