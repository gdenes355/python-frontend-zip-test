# Complete the code so that if any vowel gets entered (in lower case), then 'Vowel' is printed. If anything else is entered then 'Consonant' is printed

l = input()

if l == 'a' or l == 'e' or l == 'i':
  print("Vowel")

