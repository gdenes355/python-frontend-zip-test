p = input(Enter your password)
print(Your password is p)
