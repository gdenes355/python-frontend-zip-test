title = "Harry Potter and the Philosopher's Stone"
print("title")