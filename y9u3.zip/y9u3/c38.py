# Extend this code so that if a is 'Cool' and b is 'Bananas' then 'Australia' is printed. Also, if a is 'Anakin' and b is 'Skywalker' then 'Darth Vader' is printed. If none of these combinations of input occur, then 'Fade to black' is printed.

a = input()
b = input()

if a == "Hi" and b == "Ho":
  print("It's off to work we go")
