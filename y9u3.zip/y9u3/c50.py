repeat = True

while repeat == True
print("Enter a number that is at least 10")
n = int(input())
repeat = ...
print("The number is", n)
