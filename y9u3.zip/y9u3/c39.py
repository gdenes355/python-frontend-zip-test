# Complete the code so that if day is 'Saturday' or 'Sunday', and meal is 'Breakfast', you should print '11am'. If day is anything else and the meal is 'Breakfast', print '7am'. If the meal is anything else, print 'Hungry'.

day = input()
meal = input()

if meal == "Breakfast":
  if a == "Saturday":
    print("11am")
