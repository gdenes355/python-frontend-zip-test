x = input()
print x
