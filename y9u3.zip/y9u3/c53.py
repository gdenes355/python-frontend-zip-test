# The user will enter 6 numbers. Add up any ones larger than 100, and then print the result

total = 0
x = 1

print("Enter a number")
n = int(input())


print("The total was",total)
