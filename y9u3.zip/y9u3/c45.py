# Print out the average test score from a class of 6 students

total = 0
x = 1
# Need a line here to start the loop

print("Enter score for student",x)
score = int(input())
total = 0 # Need to change this line
x = x + 1
average = 0 # Need to change this line
print("The average score is",average)
