number = 20
print(number * 2)