print(Excellent)
