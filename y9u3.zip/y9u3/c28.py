code = 492
keypad = int(input()

if code == keypad:
    print("Come In")
else:
print("Go Away")
