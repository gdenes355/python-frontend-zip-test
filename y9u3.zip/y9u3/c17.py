x = input()
print(x "was input")

