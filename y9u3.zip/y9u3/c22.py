secret = "Neo"
guess = input()

if guess == secret
    print("There is no spoon.")

print("Finished")
