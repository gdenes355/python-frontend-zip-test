Print Cool Bananas
