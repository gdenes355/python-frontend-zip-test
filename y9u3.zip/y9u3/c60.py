# This challenge is the same as the last one. However, if the co-ordinate has the same x and y value then print 'Diagonal' instead of the co-ordinate.
# 
# e.g. if x = 3 and y = 2 then you would print:
# Diagonal
# ( 0 , 1 )
# ( 0 , 2 )
# ( 1 , 0 )
# Diagonal
# ( 1 , 2 )
# ( 2 , 0 )
# ( 2 , 1 )
# Diagonal
# ( 3 , 0 )
# ( 3 , 1 )
# ( 3 , 2 )

x_end = int(input())
y_end = int(input())

x = 0
y = 0


print("Diagonal")
print("(", x , ",", y , ")")
