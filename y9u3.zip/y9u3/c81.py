# Our street has houses numbered from 1 - 10. 
# Houses numbered 1-5 are on the East side of the street 
# and the others are on the West side of the street. 

h = int(input())
if h >= .... and h <= ....:
  print ...
  
elif

else

