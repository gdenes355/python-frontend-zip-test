# Write some code to get input from the user, which will be a number.
# If the number is smaller than 10, print 'Yawn' and nothing else. If the number is smaller than 20, print 'Hmmm' and nothing else. If the number is smaller than 100, print 'Interesting' and nothing else. If the number is 100 exactly, print 'Bingo'. If the number is bigger than 100, print 'Whoa'.


