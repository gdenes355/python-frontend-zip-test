code = "Caput Draconis"
answer = input()

if code == answer:
    print("Enter")
else
    print("Blocked")
  
print("Finished")
