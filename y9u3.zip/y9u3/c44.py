# Print out the first n terms of the 7 times table

terms = int(input())

x = 1
while x <= terms
print(x,"* 7 =",0)
x = x + 1
