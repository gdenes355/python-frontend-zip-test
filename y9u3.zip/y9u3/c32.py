dice = int(input())

if dice = 1:
  print("One")
elif dice == 3:
print("Three")
elif dice == 5
print("Five")
else
  print("Even")
