x = input
print(x)
