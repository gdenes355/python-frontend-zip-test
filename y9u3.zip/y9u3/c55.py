# The user will enter either 'Even' or 'Odd', followed by a number, x, (which will be either even or odd corresponding to their first input). 
# If they enter 'Even', print the first 10 even numbers larger than x in ascending order. If they enter 'Odd', print the last 10 odd number smaller than x in descending order.
# e.g. 'Even' '10' -> 12 14 16 18 20 22 24 26 28 30 [but on separate lines]
# e.g. 'Odd' '25' -> 23 21 19 17 15 13 11 9 7 5 [but on separate lines]

even_or_odd = input()
x = int(input())
