print("Fox")
print("Quick")
print("The")
print("Brown")
