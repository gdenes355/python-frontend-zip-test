secret = "Trinity"
guess = input()

if guess == secret:
print("I know kung foo.")

print("Finished")
