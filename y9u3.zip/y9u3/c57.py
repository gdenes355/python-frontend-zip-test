# The user will enter either numbers, or the word 'Stop'. You must add up any numbers smaller than 10, and count how many numbers are larger than 20. When 'Stop' is entered, print the results

count = 0
total = 0


x = input()



print("Total of numbers under 10 is",total)
print("Number of numbers more than 20 is",count)
