x = input()
print("x")

