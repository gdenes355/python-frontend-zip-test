code = 314
number = int input 

if ...:

