repeat = True

while repeat == True:
  print("Enter password")
  p = input()
  if ...
    repeat = False

print("Open")
