print("Perfect)
