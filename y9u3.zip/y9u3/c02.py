x = 10
print(x)
x = 2 * x
x = x + 11
