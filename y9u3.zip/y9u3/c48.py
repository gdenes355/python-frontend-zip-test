# Keep asking for numbers as input, but stop when -1 is entered and print how many numbers were entered, excluding the final '-1'.

count = 0
repeat = ...
while ...
print("Enter a number")
num = int(input())
if num == -1:
else
count = count + 1

print("There were" count "numbers")
