word = "Fox"
print(word)
word = "Quick"
word = "The"
print(word)
print(word)
word = "Brown"
print(word)
