x = input()
print("{" x "}")

