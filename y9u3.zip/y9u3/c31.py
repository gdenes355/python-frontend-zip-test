lottery = int(input())

if lottery < 100:
  print("Too small")
elif lottery > 100
  print("Too big")
else:
  print("Just right")

