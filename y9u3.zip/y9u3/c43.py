# Add up n separate numbers and print the total at the end

how_many = int(input())

total = 0

x = 1
while x <= how_many:
num = int(input())
total = total + num
x = x + 1
print("The total is" total)
