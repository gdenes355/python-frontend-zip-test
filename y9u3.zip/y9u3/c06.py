print("Hot diggity dog')
