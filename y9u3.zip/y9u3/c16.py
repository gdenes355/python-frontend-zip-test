x = input()
print("Hello" x)

