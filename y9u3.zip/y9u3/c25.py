# Write some code to get input from the user, and if they enter 'White Rabbit' then you should print 'Follow it'. Print 'Finished' at the end of your program
