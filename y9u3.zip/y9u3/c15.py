x = input()
print "x"

