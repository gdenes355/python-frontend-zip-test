secret = "Morpheus"
guess = input()

if guess = secret:
    print("I think he likes it.")

print("Finished")
