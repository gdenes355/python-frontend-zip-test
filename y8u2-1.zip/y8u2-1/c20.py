n = [ "", "" ]

name1 = input()
name2 = input()

# Complete this line to add the first name to the first position in the list
n[0] = _

# Complete this line to add the second name to the second position in the list
n[_] = _

print("The names are", n[0], "and", n[1])