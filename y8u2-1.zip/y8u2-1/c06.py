pi = [ ]

print(pi)
