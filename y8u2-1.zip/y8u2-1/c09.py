# DO NOT CHANGE THIS NEXT LINE
days = [ "Monday" , "Tuesday" , "Wednesday" ]

# => replace the blank in this line
x = days[_]

print(x) # Do not edit this line
