


print(weekend)
