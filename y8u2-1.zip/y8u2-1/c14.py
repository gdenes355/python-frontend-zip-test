# DO NOT CHANGE THIS NEXT LINE
first = [ "philosopher" , "chamber" , "prisoner" ]

# => complete this next line
n = len(first

print("There are", n, "books.") # Do not edit this line
