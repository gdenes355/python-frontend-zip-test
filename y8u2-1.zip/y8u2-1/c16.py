# DO NOT CHANGE THIS NEXT LINE
series = [ "philosopher" , "chamber" , "prisoner" , "goblet" , "order" , "prince" , "hallows" ]

# => complete this line here
book_count = _

print("There are", book_count , "books.") # Do not edit this line