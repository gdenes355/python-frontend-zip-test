# DO NOT CHANGE THIS NEXT LINE
rhyme = ["twinkle", "big", "star"]

# => complete the blank in this line
rhyme[_] = "little"

print(rhyme[0], rhyme[0], rhyme[1], rhyme[2]) # Do not edit this line
