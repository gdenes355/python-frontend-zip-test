lucky = 7

print(lucky)
