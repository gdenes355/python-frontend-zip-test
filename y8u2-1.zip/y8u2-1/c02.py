zoo = ]

print()
