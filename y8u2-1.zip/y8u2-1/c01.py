x = [

print(x)
