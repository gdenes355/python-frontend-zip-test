Add some Python on line 5 in a similar way to the last challenge so that `Ripe tomatoes are red` is printed, by reading from the list.





