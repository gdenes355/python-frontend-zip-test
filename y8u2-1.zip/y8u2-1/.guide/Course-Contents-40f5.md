# The Year 8 Python Course for Lists in Python
 - Understand why lists are necessary
 - Be able to create a list in Python using `[]`
 - Be able to use the `[]` notation to read an element of a list
 - Be able to change an element of a list using assignment (=)
 - Be able to use the `len()` function with a list
 - Be able to use a `while` loop to process a list
 - Be able to use the `append()`, `remove()` and `pop()` methods for lists in Python
