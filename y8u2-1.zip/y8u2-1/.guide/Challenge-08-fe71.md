Write some Python code which does this
 1. Create a list called `weekend` with the words Saturday and Sunday in it
 1. Print the list
 




