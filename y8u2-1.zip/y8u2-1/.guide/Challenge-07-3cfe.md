Write some Python code which does this
 1. Create a list called `day` with the word Saturday in it (what syntax do you need to remember for strings?)
 1. Print the list
 
 



