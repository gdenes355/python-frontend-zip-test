Correct the syntax errors in this code which should
 1. Create a list called `lucky` with the number 7 in it
 1. Print the list
 




