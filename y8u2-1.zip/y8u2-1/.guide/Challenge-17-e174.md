Fill in the index number on line 5 so that `twinkle twinkle little star` is printed.





