Write some Python code which does the following:
 1. Create a list called `pi` with the numbers 3, 1 and 4 in it in that order
    (note: you use commas to separate your list items)
 2. Print the list
 




