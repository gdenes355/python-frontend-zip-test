Can you edit line 5 to add in the correct syntax and index number so that `hip hip hooray` is printed?





