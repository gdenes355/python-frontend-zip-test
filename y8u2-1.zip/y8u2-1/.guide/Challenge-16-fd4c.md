Can you add a line of code that uses `len()` so that this code prints how many items are in the list?





