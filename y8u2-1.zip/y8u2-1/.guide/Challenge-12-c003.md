Add some Python in a similar way to the last challenge so that `Ripe bananas are yellow` is printed, by reading from the list.





