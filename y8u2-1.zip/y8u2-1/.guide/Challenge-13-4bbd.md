Can you change the print() statement so that the odd numbers are printed from the list?





