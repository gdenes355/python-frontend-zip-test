Can you complete the line of Python to change the 10 to a 9 in the list called `squares` without editing line 2?





