Write some Python code which does this
 1. Creates a list called `unlucky` with the number 13 in it
 1. Print the list
 




