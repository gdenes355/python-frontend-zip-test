The Python program will be given two names as input when the test is run. Can you write 2 lines of Python to:
 1. put `name1` into the first position in list `n`
 1. put `name2` into the second position in list `n`
 
Do not change the `print()` line.





