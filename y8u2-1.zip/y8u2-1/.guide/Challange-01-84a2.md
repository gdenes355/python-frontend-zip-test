Correct the syntax errors in this code which should
 1. Create an empty list called `x`
 1. Print the list
 




