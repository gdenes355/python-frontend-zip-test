Put a number in between the square brackets on line 5 so that `I like Pizza` is printed.





