Write some code which does the following:
 1. Create an empty list called `books`
 1. Print the list
 
 
 

 
