Elements in a list have an index number, which starts at zero for the first element.

Put an index number in between the square brackets on line 5 so that `Monday` is printed.





