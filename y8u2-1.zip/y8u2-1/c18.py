# DO NOT CHANGE THIS NEXT LINE
cheer = [ "toe", "hooray" ]

# => complete this next line
cheer = "hip"

print(cheer[0], cheer[0], cheer[1])
