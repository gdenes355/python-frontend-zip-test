# DO NOT CHANGE THIS NEXT LINE
squares = [ 1, 4, 10, 16 ]

# => complete this next line
squares[_] = _


print("These are square numbers:", squares[0], squares[1], squares[2], squares[3]) # Don't change this line
