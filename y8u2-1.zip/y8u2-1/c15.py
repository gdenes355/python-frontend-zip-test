# DO NOT CHANGE THIS NEXT LINE
last = [ "goblet" , "order" , "prince" ]

# => complete this next line
n = len(_)

print("There are", n, "books.") # Do not edit this line
