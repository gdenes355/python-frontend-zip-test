# DO NOT CHANGE THIS NEXT LINE
nums = [ 3 , 2 , 7 , 4 , 8 , 9 ]

# complete this next line to replace the blanks
print(nums[_] , nums[_] , nums[_])
