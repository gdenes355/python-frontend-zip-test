# DO NOT CHANGE THIS NEXT LINE
colours = [ "red" , "blue" , "yellow" ]

# => complete this line
_ = colours[_]

# => replace the blank in this next line
print("Ripe bananas are", _)
