# DO NOT CHANGE THIS NEXT LINE
food = [ "Apples" , "Pizza" , "Celery" ]

# => replace the blank in this line
x = food[_]

print("I like", x) # Do not edit this line
