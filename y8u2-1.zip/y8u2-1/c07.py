day = 

print(day)
