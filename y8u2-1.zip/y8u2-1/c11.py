# DO NOT CHANGE THIS NEXT LINE
colours = [ "red" , "blue" , "yellow" ]

# => complete this line to store the first list item into c
c = colours

print("Ripe tomatoes are", c) # Do not edit this line
